import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InternNavPageRoutingModule } from './intern-nav-routing.module';

import { InternNavPage } from './intern-nav.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InternNavPageRoutingModule
  ],
  declarations: [InternNavPage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class InternNavPageModule {}
