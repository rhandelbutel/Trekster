import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InternNavPage } from './intern-nav.page';

describe('InternNavPage', () => {
  let component: InternNavPage;
  let fixture: ComponentFixture<InternNavPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(InternNavPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
