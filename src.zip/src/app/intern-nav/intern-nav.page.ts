import { Component, OnInit } from '@angular/core';
import { onSnapshot, collection, query, where, getDocs, getFirestore, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { getAuth, deleteUser, signInWithEmailAndPassword } from 'firebase/auth';
import { ToastController, LoadingController } from '@ionic/angular/standalone';

@Component({
  selector: 'app-intern-nav',
  templateUrl: './intern-nav.page.html',
  styleUrls: ['./intern-nav.page.scss'],
  standalone: false,
})
export class InternNavPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  requestedUsers: any[] = [];
  selectedUserId: string | null = null;
  selectedUserEmail: string | null = null;
  selectedUserPassword: string | null = null; 
  showApprovePopup = false;
  showRejectPopup = false;
  isLoading: boolean = false;
  unsubscribeUsersListener!: () => void;


ionViewWillEnter() {
  const db = getFirestore();
  const q = query(collection(db, 'users'), where('approved', '==', false), where('role', '==', 'worker'));

  // Unsubscribe previous listener if any (optional but recommended)
  if (this.unsubscribeUsersListener) {
    this.unsubscribeUsersListener();
  }

  // Listen to changes in real-time
  this.unsubscribeUsersListener = onSnapshot(q, (querySnapshot) => {
    this.requestedUsers = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  });
}

ionViewWillLeave() {
  // Unsubscribe from listener to avoid memory leaks
  if (this.unsubscribeUsersListener) {
    this.unsubscribeUsersListener();
  }
}
  confirmApprove(userId: string) {
    this.selectedUserId = userId;
    this.showApprovePopup = true;
  }

  confirmReject(userId: string, email: string) {
    this.selectedUserId = userId;
    this.selectedUserEmail = email;
    this.showRejectPopup = true;
  }

  async approveUser() {
    this.isLoading = true; 
    if (!this.selectedUserId) return;
    const db = getFirestore();
    await updateDoc(doc(db, 'users', this.selectedUserId), { approved: true });
    this.presentToast('top', 'User approved!');
    this.resetPopupState();
    this.ionViewWillEnter();
  }

  async rejectUser() {
    this.isLoading = true; 
    if (!this.selectedUserId || !this.selectedUserEmail) return;

    const db = getFirestore();

    // Step 1: Delete Firestore user document
    await deleteDoc(doc(db, 'users', this.selectedUserId));

    // Step 2: Try to delete Firebase Auth account (optional & tricky unless you have user password)
    // You can skip this if not managing Firebase Auth deletions as admin
    try {
      const auth = getAuth();
      const adminEmail = 'admin@example.com'; // your admin email
      const adminPass = 'admin-password';     // your admin password

      // Sign in as admin (must be a privileged account)
      await signInWithEmailAndPassword(auth, adminEmail, adminPass);

      // Delete user from Auth via Admin SDK (Firebase Admin required on backend)
      // ⚠️ You can't delete other users from the client SDK!
      // So just remove from Firestore and let user re-register.

    } catch (err) {
      console.warn('Skipping Firebase Auth deletion. Firestore user removed.');
    }

    this.presentToast('top', 'User rejected and removed.');
    this.resetPopupState();
    this.ionViewWillEnter();
  }

  resetPopupState() {
    this.showApprovePopup = false;
    this.showRejectPopup = false;
    this.selectedUserId = null;
    this.selectedUserEmail = null;
  }

  async presentToast(position: 'top' | 'middle' | 'bottom', message: string) {
    const toast = document.createElement('ion-toast');
    toast.message = message;
    toast.duration = 2000;
    toast.position = position;
    document.body.appendChild(toast);
    return toast.present();
  }


}
