import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InternNavPage } from './intern-nav.page';

const routes: Routes = [
  {
    path: '',
    component: InternNavPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InternNavPageRoutingModule {}
