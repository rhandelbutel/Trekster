import { Component, OnInit } from '@angular/core';
import { ToastController, LoadingController } from '@ionic/angular/standalone';
import { Router } from '@angular/router';
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { getFirestore, collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";



@Component({
  selector: 'app-signin',
  templateUrl: './signin.page.html',
  styleUrls: ['./signin.page.scss'],
  standalone: false,
})
export class SigninPage implements OnInit {

  constructor(private loadingController: LoadingController, private router: Router, private toastController: ToastController) { }
  ngOnInit() {
    
  }
  
  email: string = '';
  password: string = ''; 
  showPassword: boolean = false;
  isLoading: boolean = false;

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  async checkIfUserExists(email: string): Promise<boolean> {
    const db = getFirestore();
    try {
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where("email", "==", email));
      const querySnapshot = await getDocs(q);
      return !querySnapshot.empty;
    } catch (error) {
      console.error("Error checking user:", error);
      return false;
    }
  }

  async signin() {
  if (!this.email?.trim() || !this.password?.trim()) {
    this.presentToast('top', 'Please fill all fields.');
    return;
  }

  this.isLoading = true;

  try {
    const auth = getAuth();
    const db = getFirestore();

    const userCredential = await signInWithEmailAndPassword(auth, this.email, this.password);
    const user = userCredential.user;

    const userDocRef = doc(db, 'users', user.uid);
    const userDocSnap = await getDoc(userDocRef);

    if (userDocSnap.exists()) {
      const userData = userDocSnap.data() as { role: string; approved?: boolean; [key: string]: any };
      const role = userData.role;
      const approved = userData.approved;

      // Check approval only if role is 'worker'
      if (role === 'worker' && !approved) {
        this.presentToast('top', 'Your account is pending approval.');
        return;
      }

      this.presentToast('top', `Hola! Welcome back, ${userData['username'] || role}! 🎉`);

      if (role === 'worker') {
        this.router.navigate(['/home']);
      } else if (role === 'supervisor') {
        this.router.navigate(['/admin-home']);
      } else {
        this.presentToast('top', 'Unknown role. Please contact support.');
        return;
      }

      // Clear fields
      this.email = '';
      this.password = '';
    } else {
      this.presentToast('top', 'User data not found.');
    }
  } catch (error) {
    const errorCode = (error as any).code;

    if (errorCode === 'auth/invalid-credential') {
      const userExists = await this.checkIfUserExists(this.email);
      this.presentToast('top', userExists ? 'Wrong password. Please try again.' : 'No account? Sign up.');
    } else if (errorCode === 'auth/invalid-email') {
      this.presentToast('top', 'Invalid email. Please try again.');
    } else {
      this.presentToast('top', 'Signin failed');
      console.error('Signin error:', error);
    }
  } finally {
    this.isLoading = false;
  }
}

  async presentToast(
    position: 'top' | 'middle' | 'bottom' = 'top',
    message: string = ''
  ) {
    const toast = await this.toastController.create({
      message: message,
      duration: 1500,
      position: position,
    });
  
    await toast.present();
  }
  
  gotoSignup() {
    this.email = '';
    this.password = '';
    this.router.navigate(['/signup'], { replaceUrl: true });
  }
}
