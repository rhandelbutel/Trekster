import { Component, OnInit, NgZone, OnDestroy } from '@angular/core';
import { MenuController, ToastController } from '@ionic/angular';

// Modular Firebase Authentication imports
import { Auth, onAuthStateChanged, User, Unsubscribe as AuthUnsubscribe } from '@angular/fire/auth'; // Renamed Unsubscribe for clarity

// Modular Firebase Firestore imports
import { Firestore, collection, doc, addDoc, updateDoc, query, orderBy, where, getDocs, onSnapshot, Unsubscribe as FirestoreUnsubscribe } from '@angular/fire/firestore'; // Renamed Unsubscribe for clarity
import { Timestamp } from 'firebase/firestore';

interface AttendanceRecord {
  id?: string; // Document ID
  timeIn: Timestamp; // Use Firebase v9 Timestamp
  timeOut: Timestamp | null;
  status: 'ongoing' | 'completed' | 'auto-timed-out';
  totalTime: number | null; // in minutes
  date: string; // "YYYY-MM-DD"
}

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.page.html',
  styleUrls: ['./attendance.page.scss'],
  standalone: false
})
export class AttendancePage implements OnInit, OnDestroy {
  currentDateTime: string = '';
  userEmail: string | null = null;
  currentUser: User | null = null;
  private timer: any;

  // FIX 1: Change Subscription type to the Unsubscribe function type
  private authSubscription: AuthUnsubscribe | undefined;
  private attendanceSubscription: FirestoreUnsubscribe | undefined;

  attendanceHistory: AttendanceRecord[] = [];
  currentOngoingRecord: AttendanceRecord | null = null;

  constructor(
    private ngZone: NgZone,
    private auth: Auth,
    private firestore: Firestore,
    private menu: MenuController,
    private toastController: ToastController
  ) { }

  openMenu() {
    this.menu.open('attendance');
  }

  ngOnInit() {
    this.authSubscription = onAuthStateChanged(this.auth, (user: User | null) => {
      this.ngZone.run(() => {
        this.currentUser = user;
        if (user && user.email) {
          console.log('User logged in:', user.email);
          this.userEmail = user.email;
          this.loadAttendanceHistory();
          this.checkForAutoTimeout();
        } else {
          console.log('No logged-in user or email found');
          this.userEmail = null;
          this.attendanceHistory = [];
          this.currentOngoingRecord = null;
          if (this.attendanceSubscription) {
            this.attendanceSubscription(); // Call the unsubscribe function
            this.attendanceSubscription = undefined;
          }
        }
      });
    });

    this.updateClock();
    this.timer = setInterval(() => {
      this.updateClock();
    }, 1000);
  }

  ngOnDestroy() {
    clearInterval(this.timer);
    if (this.authSubscription) {
      this.authSubscription(); // Call the unsubscribe function
    }
    if (this.attendanceSubscription) {
      this.attendanceSubscription(); // Call the unsubscribe function
    }
  }

  updateClock() {
    const now = new Date();
    this.currentDateTime = now.toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  }

  async presentToast(message: string, color: string = 'primary', duration: number = 2000) {
    const toast = await this.toastController.create({
      message: message,
      duration: duration,
      color: color,
      position: 'top'
    });
    toast.present();
  }

  async timeIn() {
    // FIX 2: Ensure currentUser and uid are non-null before proceeding
    if (!this.currentUser?.uid) { // Using optional chaining ?. and nullish coalescing ?? for concise check
      this.presentToast('Please log in to time in.', 'warning');
      return;
    }

    if (this.currentOngoingRecord && this.currentOngoingRecord.status === 'ongoing') {
      this.presentToast('You are already timed in.', 'warning');
      return;
    }

    const now = new Date();
    const todayDate = now.toISOString().slice(0, 10);

    const newRecord: AttendanceRecord = {
      timeIn: Timestamp.fromDate(now),
      timeOut: null,
      status: 'ongoing',
      totalTime: null,
      date: todayDate,
    };

    try {
      await addDoc(collection(this.firestore, `attendance/${this.currentUser.uid}/records`), newRecord);
      this.presentToast('Timed in successfully!', 'success');
    } catch (error) {
      console.error('Error timing in:', error);
      this.presentToast('Failed to time in. Please try again.', 'danger');
    }
  }

  async timeOut() {
    // FIX 2: Ensure currentUser and uid are non-null before proceeding
    if (!this.currentUser?.uid) {
      this.presentToast('Please log in to time out.', 'warning');
      return;
    }

    if (!this.currentOngoingRecord || this.currentOngoingRecord.status !== 'ongoing') {
      this.presentToast('You are not currently timed in or already timed out.', 'warning');
      return;
    }

    const now = new Date();
    const timeInDate = this.currentOngoingRecord.timeIn.toDate();
    const totalTimeMinutes = (now.getTime() - timeInDate.getTime()) / (1000 * 60);

    try {
      // FIX 2: Assert currentOngoingRecord.id is not null, as it's guaranteed by !this.currentOngoingRecord check
      await updateDoc(doc(this.firestore, `attendance/${this.currentUser.uid}/records`, this.currentOngoingRecord.id!), {
        timeOut: Timestamp.fromDate(now),
        status: 'completed',
        totalTime: totalTimeMinutes,
      });
      this.presentToast('Timed out successfully!', 'success');
    } catch (error) {
      console.error('Error timing out:', error);
      this.presentToast('Failed to time out. Please try again.', 'danger');
    }
  }

  private loadAttendanceHistory() {
    // FIX 2: Ensure currentUser and uid are non-null before proceeding
    if (!this.currentUser?.uid) return;

    const recordsCollectionRef = collection(this.firestore, `attendance/${this.currentUser.uid}/records`);
    const q = query(recordsCollectionRef, orderBy('timeIn', 'desc'));

    this.attendanceSubscription = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        const records: AttendanceRecord[] = [];
        querySnapshot.forEach((docSnap) => {
          const data = docSnap.data() as AttendanceRecord;
          const id = docSnap.id;
          records.push({ id, ...data });
        });
        this.attendanceHistory = records;
        this.currentOngoingRecord = records.find(record => record.status === 'ongoing') || null;
      });
    }, (error) => {
      console.error('Error loading attendance history:', error);
      this.presentToast('Failed to load attendance history.', 'danger');
    });
  }

  private checkForAutoTimeout() {
    // FIX 2: Capture uid into a local variable after initial check to avoid null assertion in loops
    if (!this.currentUser?.uid) return;
    const userUid = this.currentUser.uid; // Capture uid here

    const recordsCollectionRef = collection(this.firestore, `attendance/${userUid}/records`);
    const q = query(recordsCollectionRef, where('status', '==', 'ongoing'));

    getDocs(q)
      .then(async (querySnapshot) => {
        querySnapshot.forEach(async (docSnap) => {
          const record = docSnap.data() as AttendanceRecord;
          const recordId = docSnap.id;
          const timeInDate = record.timeIn.toDate();
          const now = new Date();

          const autoTimeoutTime = new Date(timeInDate.getFullYear(), timeInDate.getMonth(), timeInDate.getDate(), 16, 0, 0); // 4 PM

          if (now > autoTimeoutTime && record.status === 'ongoing') {
            const totalTimeMinutes = (autoTimeoutTime.getTime() - timeInDate.getTime()) / (1000 * 60);
            // FIX 2: Use the locally captured userUid
            console.log(`Auto-timing out record ${recordId} for user ${userUid}`);
            try {
              // FIX 2: Use the locally captured userUid
              await updateDoc(doc(this.firestore, `attendance/${userUid}/records`, recordId), {
                timeOut: Timestamp.fromDate(autoTimeoutTime),
                status: 'auto-timed-out',
                totalTime: totalTimeMinutes,
              });
              this.presentToast('Auto-timed out due to inactivity (4 PM rule).', 'warning', 3000);
            } catch (error) {
              console.error('Error during auto-timeout:', error);
              this.presentToast('Failed to auto-timeout. Please check manually.', 'danger');
            }
          }
        });
      })
      .catch(error => {
        console.error('Error checking for auto-timeout:', error);
        this.presentToast('Error checking for forgotten timeouts.', 'danger');
      });
  }

  formatTime(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  }

  formatDate(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' });
  }

  formatTotalTime(minutes: number | null): string {
    if (minutes === null) return 'N/A';
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);
    return `${hours}h ${remainingMinutes}m`;
  }
}