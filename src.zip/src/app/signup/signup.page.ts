import { Component, OnInit } from '@angular/core';
import { createUserWithEmailAndPassword, getAuth } from 'firebase/auth';
import { getFirestore, setDoc, doc } from 'firebase/firestore';
import { Router } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular/standalone';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
  standalone: false,
})
export class SignupPage implements OnInit {
  username: string = '';
  email: string = '';
  password: string = '';
  cpassword: string = '';
  isLoading: boolean = false;
  role: string = '';


  constructor(private loadingController: LoadingController, private router: Router, private toastController: ToastController) {}
  ngOnInit() {}

  async signup() {
    if (!this.email?.trim() || !this.password?.trim() || !this.cpassword?.trim() || !this.username?.trim() || !this.role?.trim()) {
      this.presentToast('top', 'Please fill all fields.');
      return;
    }

    if (this.password !== this.cpassword) {
      this.presentToast('top','Passwords do not match. Try again.');
      return;
    }
    this.isLoading = true;
    try {
      const auth = getAuth();
      const db = getFirestore();

      const userCredential = await createUserWithEmailAndPassword(auth, this.email, this.password);
      const user = userCredential.user;

      if (!this.username.trim()) {
        this.presentToast('top','Username cannot be empty');
        return;
      }
      const isApproved = this.role === 'supervisor';
      await setDoc(doc(db, 'users', user.uid), {
        username: this.username,
        email: this.email,
        uid: user.uid,
        role: this.role,
        createdAt: new Date(),
        approved: false
      });

      this.presentToast('top', '🎉 Welcome aboard! Please wait for Approval.');
      // Removes all input text
      this.username = '';
      this.email = ''; 
      this.cpassword = '';    
      this.password = ''; 
      this.role = '';
      this.router.navigate(['/signin']); 

    } catch (error) {
      const errorCode = (error as any).code;
      const errorMessage = (error as any).message;
      
      if (errorCode === 'auth/email-already-in-use') {
        this.presentToast('top','Email is already exists.');
      } else if (errorCode === 'auth/invalid-email') {
        this.presentToast('top','Invalid email format. Please try again.');
      } else if (errorCode === 'auth/weak-password') {
        this.presentToast('top','Password should be at least 6 characters long.');
      } else {
        console.error('Error during sign up:', errorMessage);
      }
    } finally {
      this.isLoading = false; 
    }
  }
  async presentToast(
    position: 'top' | 'middle' | 'bottom' = 'top',
    message: string = ''
  ) {
    const toast = await this.toastController.create({
      message: message,
      duration: 1500,
      position: position,
    });
  
    await toast.present();
  }
  gotoSignin() {
    this.username = '';
    this.email = '';
    this.password = '';
    this.cpassword = '';
    this.role = '';
    this.router.navigate(['/signin'], { replaceUrl: true });
  }
}

