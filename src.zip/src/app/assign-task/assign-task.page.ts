import { Component, OnInit } from '@angular/core';
import { doc, onSnapshot, deleteDoc, Firestore, collection, addDoc, collectionData, query, where, getDocs } from '@angular/fire/firestore';
import { ModalController } from '@ionic/angular';
import { ToastController, LoadingController } from '@ionic/angular/standalone';
import { inject } from '@angular/core';
import { Auth } from '@angular/fire/auth';

@Component({
  selector: 'app-assign-task',
  templateUrl: './assign-task.page.html',
  styleUrls: ['./assign-task.page.scss'],
  standalone: false,
})
export class AssignTaskPage implements OnInit {

  constructor( private toastController: ToastController, private firestore: Firestore, private modalCtrl: ModalController) { }

  ngOnInit() {
    this.loadFinishedTasksRealtime();
  }
  isLoading: boolean = false;
   task = {
    assignedTo: '',
    title: '',
    description: '',
    dueDate: '',
    finishedDate: '',
  };

  // Add task 
  async addTask() {
    if (!this.task.assignedTo || !this.task.title || !this.task.dueDate) {
      this.presentToast('top', 'Please fill in all required fields.');
      return;
    }
    this.isLoading = true;
    try {
      const userRef = collection(this.firestore, 'users');
      const q = query(userRef, where('email', '==', this.task.assignedTo));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        this.presentToast('top', 'The email you entered does not exist.');
        return;
      }

      const userDoc = querySnapshot.docs[0];
      const userData = userDoc.data() as { email: string; role: string };

      if (userData.role !== 'worker') {
        this.presentToast('top', 'The email belongs to a user who is not a worker.');
        return;
      }

      const taskRef = collection(this.firestore, 'tasks');
      await addDoc(taskRef, {
        ...this.task,
        dueDate: this.task.dueDate ? new Date(this.task.dueDate) : null,
        createdAt: new Date(),
        status: 'pending',
        assignedWorker: this.task.assignedTo,
        supervisorId: 'supervisor-uid',
      });

      this.resetForm();
      this.dismissModal();
      this.presentToast('top', 'Task added successfully!');
    } catch (error) {
      console.error('Error adding task:', error);
      this.presentToast('top', 'Something went wrong. Please try again.');
    }finally {
    this.isLoading = false;
  }
  }
  // End of Add task 

  dismissModal() {
    this.modalCtrl.dismiss();
  }

  resetForm() {
    this.task = {
      assignedTo: '',
      title: '',
      description: '',
      dueDate: '',
      finishedDate: '',
    };
  }

  // Printing of Ongoing Task 
  auth = inject(Auth);
  tasks: any[] = [];
  
ionViewWillEnter() {
  this.loadTasksRealtime(); 
}

loadTasksRealtime() {
  const taskRef = collection(this.firestore, 'tasks');
  const q = query(taskRef, where('status', '==', 'pending'));

  onSnapshot(q, (snapshot) => {
    this.tasks = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        dueDate: data['dueDate']?.toDate ? data['dueDate'].toDate() : data['dueDate'],
      };
    });
  });
}
// End of Printing of Ongoing Task 


// Open Delete modal on both ongoing and completed task
taskToDelete: any = null;

openDeleteModal(task: any) {
  this.taskToDelete = task;
  document.getElementById('delete')!.style.display = 'flex';
}
openDeleteModal2(task: any) {
  this.taskToDelete = task;
  document.getElementById('delete')!.style.display = 'flex';
}
// Delete confirmation modal
confirmDelete() {
  if (this.taskToDelete && this.taskToDelete.id) {
    const taskDocRef = doc(this.firestore, 'tasks', this.taskToDelete.id);
    deleteDoc(taskDocRef).then(() => {
      console.log('Task deleted!');
      this.presentToast('top', 'Task successfully deleted!');
    }).catch(err => {
      this.presentToast('top', 'Error deleting task. Try again.');
      console.error('Error deleting task:', err);
    });
  }

  this.taskToDelete = null;
  document.getElementById('delete')!.style.display = 'none';
}

cancelDelete() {
  this.taskToDelete = null;
  document.getElementById('delete')!.style.display = 'none';
}
// End of Open Delete modal on both ongoing and completed task


// Ongoing and Completed View task
selectedTask: any = null;
// Ongoing task view action button
openTaskModal(task: any) {
  this.selectedTask = task;
  document.getElementById('taskModal')!.style.display = 'block';
}
// End of Ongoing task view action button
closeTaskModal() {
  this.selectedTask = null;
  document.getElementById('taskModal')!.style.display = 'none';
}

// Completed task view action button
openTaskModal2(task: any) {
  this.selectedTask = task;
  document.getElementById('taskModal2')!.style.display = 'block';
}

closeTaskModal2() {
  this.selectedTask = null;
  document.getElementById('taskModal2')!.style.display = 'none';
}
// End of Completed task view action button
// End of Ongoing and Completed View task



// Printing of Finished task
finishedTasks: any[] = [];

loadFinishedTasksRealtime() {
  const tasksRef = collection(this.firestore, 'tasks');
  const q = query(tasksRef, where('status', '==', 'finished'));

  onSnapshot(q, (querySnapshot) => {
    this.finishedTasks = querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        dueDate: data['dueDate']?.toDate ? data['dueDate'].toDate() : data['dueDate'],
        finishedDate: data['finishedDate']?.toDate ? data['finishedDate'].toDate() : data['finishedDate'],
      };
    });
  }, (error) => {
    console.error('Error loading finished tasks:', error);
  });
}
// End Printing of Finished task


  // Toast Alert
  async presentToast(
    position: 'top' | 'middle' | 'bottom' = 'top',
    message: string = ''
  ) {
    const toast = await this.toastController.create({
      message: message,
      duration: 1500,
      position: position,
    });
  
    await toast.present();
  }
}
// End of Toast Alert