import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';
import { Firestore, collection, query, where, getDocs, orderBy, DocumentData } from '@angular/fire/firestore'; // Import DocumentData
import { ToastController, LoadingController } from '@ionic/angular/standalone';
import { Auth, User } from '@angular/fire/auth';
import { Timestamp } from 'firebase/firestore';

// Define the AttendanceRecord interface (copy from your home.page.ts for consistency)
interface AttendanceRecord {
  id?: string;
  timeIn: Timestamp;
  timeOut: Timestamp | null;
  status: 'ongoing' | 'completed' | 'auto-timed-out';
  totalTime: number | null; // in minutes
  date: string;
}
interface InternAttendance {
  email: string;
  uid: string; // User ID to fetch their attendance records
  records: AttendanceRecord[]; // Their attendance records
}

@Component({
  selector: 'app-ojt-logs',
  templateUrl: './ojt-logs.page.html',
  styleUrls: ['./ojt-logs.page.scss'],
  standalone: false
})
export class OjtLogsPage implements OnInit, OnDestroy {
  allInternsAttendance: InternAttendance[] = [];
  isLoading: boolean = true;
  private currentUser: User | null = null;

  constructor(
    private firestore: Firestore,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private ngZone: NgZone,
    private auth: Auth
  ) { }

  async ngOnInit() {
    this.auth.onAuthStateChanged(async (user) => {
      this.ngZone.run(() => { // Ensure UI updates within Angular's zone
        this.currentUser = user;
        if (user) {
          console.log('User logged in:', user.email);
          // Removed permission check to always attempt fetching logs
          // **WARNING: This removes client-side access control.
          //            Rely heavily on Firestore Security Rules for real security.**
          this.fetchAllInternAttendance();
        } else {
          console.warn('No user logged in. Cannot fetch OJT logs.');
          this.isLoading = false;
          this.presentToast('Please log in to view OJT logs.', 'danger');
        }
      });
    });
  }

  ngOnDestroy() {
    // No specific subscriptions to unsubscribe from here, as getDocs is one-time fetch
  }

  async fetchAllInternAttendance() {
    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: 'Fetching OJT logs...',
    });
    await loading.present();

    try {
      this.allInternsAttendance = []; // Clear previous data

      // 1. Fetch all users with role 'worker'
      const usersRef = collection(this.firestore, 'users');
      // **IMPORTANT: Confirm 'worker' is the correct role for your OJT students in Firestore.**
      const internQuery = query(usersRef, where('role', '==', 'worker'));
      const internSnapshot = await getDocs(internQuery);

      // FIX FOR TS4111 ERROR: Accessing 'email' using bracket notation or by casting to 'any'
      console.log('Users with role "worker" fetched:', internSnapshot.docs.map(doc => (doc.data() as DocumentData)['email']));
      // Alternatively, if you're sure 'email' exists:
      // console.log('Users with role "worker" fetched:', internSnapshot.docs.map(doc => doc.data()['email']));


      if (internSnapshot.empty) {
        console.log('No users with the role "worker" found.');
        this.presentToast('No OJT logs found. No users with role "worker".', 'warning');
        this.isLoading = false;
        await loading.dismiss();
        return;
      }

      const internPromises = internSnapshot.docs.map(async (userDoc) => {
        const userData = userDoc.data() as DocumentData; // Explicitly cast userData for safer access
        const internUid = userDoc.id; // UID is the document ID for users
        const internEmail = userData['email']; // Access email using bracket notation

        if (internEmail) {
          // 2. For each intern, fetch their attendance records
          const attendanceRecordsRef = collection(this.firestore, `attendance/${internUid}/records`);
          // Fetch all records, ordered by timeIn in descending order (latest first)
          const attendanceQuery = query(attendanceRecordsRef, orderBy('timeIn', 'desc'));
          const attendanceSnapshot = await getDocs(attendanceQuery);

          const records: AttendanceRecord[] = [];
          attendanceSnapshot.forEach((recordDoc) => {
            records.push({ id: recordDoc.id, ...recordDoc.data() } as AttendanceRecord);
          });
          console.log(`Fetched ${records.length} records for ${internEmail}`); // Log number of records per intern

          // Only return intern data if they actually have records to display
          if (records.length > 0) {
            return { email: internEmail, uid: internUid, records: records } as InternAttendance;
          }
        }
        return null; // Return null if email is missing or no records found for this intern
      });

      const resolvedInterns = await Promise.all(internPromises);

      this.ngZone.run(() => {
        // Filter out any nulls (interns with no records or missing email)
        this.allInternsAttendance = resolvedInterns.filter(intern => intern !== null) as InternAttendance[];

        if (this.allInternsAttendance.length === 0) {
          this.presentToast('No OJT attendance records found for "worker" roles.', 'warning');
          console.log('No OJT attendance records found after filtering for "worker" roles with records.');
        } else {
          console.log('Fetched all intern attendance (OJT Logs):', this.allInternsAttendance);
        }
      });

    } catch (error) {
      console.error('Error fetching all intern attendance (OJT Logs):', error);
      this.presentToast('Failed to load OJT logs. Please try again.', 'danger');
    } finally {
      this.isLoading = false;
      await loading.dismiss();
    }
  }

  async presentToast(message: string, color: string = 'primary', duration: number = 2000) {
    const toast = await this.toastController.create({
      message: message,
      duration: duration,
      color: color,
      position: 'bottom' // Changed toast position to bottom
    });
    toast.present();
  }

  // Helper functions for formatting time and date (no changes needed)
  formatTime(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  }

  formatDate(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' });
  }

  formatTotalTime(minutes: number | null): string {
    if (minutes === null) return 'N/A';
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);
    return `${hours}h ${remainingMinutes}m`;
  }
}