import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OjtLogsPage } from './ojt-logs.page';

describe('OjtLogsPage', () => {
  let component: OjtLogsPage;
  let fixture: ComponentFixture<OjtLogsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(OjtLogsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
