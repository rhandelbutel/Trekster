import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OjtLogsPageRoutingModule } from './ojt-logs-routing.module';

import { OjtLogsPage } from './ojt-logs.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OjtLogsPageRoutingModule
  ],
  declarations: [OjtLogsPage]
})
export class OjtLogsPageModule {}
