import { Component, OnInit, NgZone } from '@angular/core';
import { Auth, onAuthStateChanged, User, updatePassword, reauthenticateWithCredential, EmailAuthProvider } from '@angular/fire/auth';
import { onSnapshot, Firestore, doc, getDoc, updateDoc  } from '@angular/fire/firestore';
import { deleteDoc, collection, addDoc, collectionData, query, where, getDocs } from '@angular/fire/firestore';
import { ToastController, LoadingController } from '@ionic/angular/standalone';
interface Task {
  id: string;
  title: string;
  dueDate: any; 
  finishedDate?: any;
  assignedWorker: string;
  status: string; 
}
@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: false
})
export class ProfilePage implements OnInit {
   userEmail: string | null = null;
  userName: string | null = null;
  userRole: string | null = null;
  isApproved: boolean | null = null;
  currentUser: User | null = null;

  newUserName: string = '';

  currentPassword: string = '';
  newPassword: string = '';
  confirmNewPassword: string = '';

  isLoadingUser: boolean = true; 
  isUpdating: boolean = false;
  isLoading: boolean = false;

  
  constructor(
    private toastController: ToastController,
    private ngZone: NgZone,
    private auth: Auth,
    private firestore: Firestore,
    private loadingController: LoadingController
  ) { }

  ngOnInit() {
    this.isLoadingUser = true; 

    onAuthStateChanged(this.auth, async (user: User | null) => {
      this.ngZone.run(async () => {
        this.currentUser = user; 

        if (user) {
          console.log('User logged in:', user.uid);
          this.userEmail = user.email;

          const userDocRef = doc(this.firestore, 'users', user.uid);
          try {
            const userDocSnap = await getDoc(userDocRef);

            if (userDocSnap.exists()) {
              const userData = userDocSnap.data();
              this.userName = userData['username'] || null;
              this.userRole = userData['role'] || null;
              this.isApproved = userData['approved'] || false;
              this.newUserName = this.userName || ''; 
              console.log('User data from Firestore:', userData);
            } else {
              console.log('No user document found for UID:', user.uid);
              this.userName = null;
              this.userRole = null;
              this.isApproved = null;
            }
          } catch (error) {
            console.error('Error fetching user document:', error);
            this.presentToast('top', 'Error fetching profile data. Please try again.', 'danger');
            this.userName = null;
            this.userRole = null;
            this.isApproved = null;
          } finally {
            this.isLoadingUser = false; 
          }
        } else {
          console.log('No logged-in user');
          this.userEmail = null;
          this.userName = null;
          this.userRole = null;
          this.isApproved = null;
          this.isLoadingUser = false;
          this.presentToast('top', 'No user logged in. Please log in to view profile.', 'warning');
        }
      });
    });
  }


  async presentToast(position: 'top' | 'middle' | 'bottom', message: string, color: string = 'dark') {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000, 
      position: position,
      color: color
    });
    await toast.present();
  }

  openEditUsernamePopup() {
    if (this.isLoadingUser) {
      this.presentToast('top', 'Please wait, loading user data...', 'warning');
      return;
    }
    if (!this.currentUser) {
      this.presentToast('top', 'You must be logged in to edit your profile.', 'danger');
      return;
    }

    const popup = document.getElementById('username');
    if (popup) {
      popup.style.display = 'block';
      this.newUserName = this.userName || '';
    }
  }

  closeEditUsernamePopup() {
    const popup = document.getElementById('username');
    if (popup) {
      popup.style.display = 'none';
      this.newUserName = this.userName || '';
    }
  }

  async confirmUsernameChange() {
     
    if (this.isUpdating) {
        this.presentToast('top', 'An update is already in progress. Please wait.', 'warning');
        return;
    }
    if (this.isLoadingUser) {
        this.presentToast('top', 'Please wait, user data is still loading.', 'warning');
        return;
    }
    if (!this.currentUser) {
      this.presentToast('top', 'No user is logged in to update the username.', 'danger');
      return;
    }
    if (!this.newUserName.trim()) {
      this.presentToast('top', 'Username cannot be empty.', 'warning');
      return;
    }
    if (this.newUserName.trim() === this.userName) {
      this.presentToast('top', 'Username is already the same.', 'primary');
      this.closeEditUsernamePopup();
      return;
    }
    this.isLoading = true;
    this.isUpdating = true; 

    const userDocRef = doc(this.firestore, 'users', this.currentUser.uid);

    try {
      await updateDoc(userDocRef, {
        username: this.newUserName.trim()
      });
      this.isLoading = false;
      this.userName = this.newUserName.trim(); 
      this.presentToast('top', 'Username updated successfully!', 'success');
      this.closeEditUsernamePopup();

    } catch (error) {
      console.error('Error updating username:', error);
      this.presentToast('top', 'Failed to update username. Please try again.', 'danger');
    } finally {
      this.isUpdating = false; 
    }
  }

  openChangePasswordPopup() {
    if (this.isLoadingUser) {
      this.presentToast('top', 'Please wait, loading user data...', 'warning');
      return;
    }
    if (!this.currentUser) {
      this.presentToast('top', 'You must be logged in to change your password.', 'danger');
      return;
    }

    const popup = document.getElementById('password');
    if (popup) {
      popup.style.display = 'block';
      this.currentPassword = '';
      this.newPassword = '';
      this.confirmNewPassword = '';
    }
  }

  closeChangePasswordPopup() {
    const popup = document.getElementById('password');
    if (popup) {
      popup.style.display = 'none';
      this.currentPassword = '';
      this.newPassword = '';
      this.confirmNewPassword = '';
    }
  }

  async confirmPasswordChange() {

    if (this.isUpdating) {
        this.presentToast('top', 'An update is already in progress. Please wait.', 'warning');
        return;
    }
    if (!this.currentUser) {
      this.presentToast('top', 'No user logged in to change password.', 'danger');
      return;
    }
    if (!this.currentUser.email) {
        this.presentToast('top', 'User email not found. Cannot re-authenticate.', 'danger');
        return;
    }



    // Input validation
    if (!this.currentPassword || !this.newPassword || !this.confirmNewPassword) {
      this.presentToast('top', 'Please fill all password fields.', 'warning');
      return;
    }
    if (this.newPassword !== this.confirmNewPassword) {
      this.presentToast('top', 'New passwords do not match.', 'warning');
      return;
    }
    if (this.newPassword === this.currentPassword) {
        this.presentToast('top', 'New password cannot be the same as the current password.', 'warning');
        return;
    }
     this.isLoading = true;
    this.isUpdating = true; 

    try {
        const credential = EmailAuthProvider.credential(this.currentUser.email!, this.currentPassword);
        await reauthenticateWithCredential(this.currentUser, credential);
        this.presentToast('top', 'Re-authentication successful.', 'success'); 

        await updatePassword(this.currentUser, this.newPassword);
         this.isLoading = false;
        this.presentToast('top', 'Password updated successfully!', 'success');
        this.closeChangePasswordPopup();
    } catch (error: any) {
        console.error('Error changing password:', error);
        let errorMessage = 'Failed to change password. Please try again.';
        let toastColor = 'danger'; 

        if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
            errorMessage = 'Incorrect current password. Please re-check.';
        } else if (error.code === 'auth/too-many-requests') {
            errorMessage = 'Too many failed attempts. Please try again later.';
            toastColor = 'warning';
        } else if (error.code === 'auth/requires-recent-login') {
            errorMessage = 'For security, please log out and log in again to change your password.';
            toastColor = 'warning';
        } else if (error.code === 'auth/invalid-email') {
            errorMessage = 'Invalid email for re-authentication. (Internal error if this happens)';
        } else if (error.code === 'auth/user-disabled') {
            errorMessage = 'Your account has been disabled.';
        } else if (error.code === 'auth/weak-password') {
            errorMessage = 'New password is too weak. Please choose a stronger one.';
            toastColor = 'warning';
        }

        this.presentToast('top', errorMessage, toastColor);
    } finally {
      this.isUpdating = false; 
    }
  }
  
  }
