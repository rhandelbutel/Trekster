import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.page.html',
  styleUrls: ['./landing.page.scss'],
  standalone: false,
})
export class LandingPage implements OnInit {
  onSwiperReady(swiperInstance: any) {
  swiperInstance.autoplay.start();
  }
  constructor(private router: Router) { }

  ngOnInit() {
    const hasLaunched = localStorage.getItem('hasLaunched');
    if (hasLaunched === 'true') {
      this.router.navigate(['/signin'], { replaceUrl: true });
    }
  }
  getStarted() {
  localStorage.setItem('hasLaunched', 'true');

  this.router.navigate(['/signin'], { replaceUrl: true });
}
}
