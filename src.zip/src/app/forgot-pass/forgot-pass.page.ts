import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { IonicModule, ToastController, LoadingController } from '@ionic/angular';
import { getAuth, sendPasswordResetEmail } from "firebase/auth";
import { getFirestore, collection, query, where, getDocs } from "firebase/firestore";

@Component({
  selector: 'app-forgot-pass',
  templateUrl: './forgot-pass.page.html',
  styleUrls: ['./forgot-pass.page.scss'],
  standalone: false,
})
export class ForgotPassPage implements OnInit {


  ngOnInit() {
  }
  email: string = '';
  isLoading: boolean = false;

  constructor(
    private router: Router,
    private toastController: ToastController,
    private loadingController: LoadingController
  ) {}

  async sendPasswordResetEmail() {
    if (!this.email?.trim()) {
      this.presentToast('top', 'Enter your email');
      return;
    }
  
    this.isLoading = true;
    
    try {
      if (!this.isValidEmail(this.email)) {
        this.presentToast('top', 'Invalid email format. Try again.');
        return;
      }
  
      const emailExists = await this.checkEmailExists(this.email);
      if (!emailExists) {
        this.presentToast('top', '❌ Email not registered.');
        return;
      }
  
      const auth = getAuth();
      await sendPasswordResetEmail(auth, this.email);
      this.presentToast('top', '📧 Check your email for reset link');
      this.router.navigate(['/signin']);
    } catch (error) {
      this.presentToast('top', 'Failed to send email. Try again.');
      console.error('Reset error:', error);
    } finally {
      this.isLoading = false;
    }
  }
  
  private isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); 
  }
  
  private async checkEmailExists(email: string): Promise<boolean> {
    const db = getFirestore();
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where("email", "==", email));
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  }

  async presentToast(position: 'top', message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position
    });
    await toast.present();
  }
  gotoSignup(){
    this.email = '';
    this.router.navigate(['/signin'], { replaceUrl: true });
  }
}
