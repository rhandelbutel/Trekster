import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Firestore, collection, query, where, onSnapshot, addDoc, updateDoc, doc, Timestamp, getDocs, orderBy } from '@angular/fire/firestore';
import { Auth, onAuthStateChanged, User, Unsubscribe as AuthUnsubscribe } from '@angular/fire/auth';
import { ToastController, LoadingController } from '@ionic/angular/standalone';
import { serverTimestamp } from 'firebase/firestore';

// Define the AttendanceRecord interface (copied from previous examples)
interface AttendanceRecord {
  id?: string; // Document ID
  timeIn: Timestamp; // Use Firebase v9 Timestamp
  timeOut: Timestamp | null;
  status: 'ongoing' | 'completed' | 'auto-timed-out';
  totalTime: number | null; // in minutes
  date: string; // "YYYY-MM-DD"
}

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: false,
})
export class HomePage implements OnInit, OnDestroy {
  currentDateTime: string = '';
  private timer: any;
  assignedTasks: any[] = [];
  userEmail: string | null = null;
  currentUser: User | null = null;

  // For managing Firebase subscriptions/unsubscribes
  private authSubscription: AuthUnsubscribe | undefined;
  private tasksSubscription: (() => void) | undefined;
  private attendanceSubscription: (() => void) | undefined;

  attendanceHistory: AttendanceRecord[] = [];
  currentOngoingRecord: AttendanceRecord | null = null;

  // --- UPDATED PROPERTIES FOR ATTENDANCE SUMMARY ---
  // The fixed target total hours for the intern/worker
  readonly targetTotalHours: number = 100; // Fixed to 100 hours as per your clarification

  totalCompletedMinutes: number = 0; // Total time completed in minutes
  totalCompletedHoursDisplay: number = 0; // Total time completed in hours, for calculations and display
  remainingHours: number = 0; // Remaining hours (targetTotalHours - totalCompletedHoursDisplay)
  // --- END UPDATED PROPERTIES ---

  constructor(
    private ngZone: NgZone,
    private auth: Auth,
    private firestore: Firestore,
    private menu: MenuController,
    private router: Router,
    private toastController: ToastController,
    private loadingController: LoadingController
  ) {}

  openMenu() {
    this.menu.open('first');
  }

  ngOnInit() {
    this.authSubscription = onAuthStateChanged(this.auth, (user: User | null) => {
      this.ngZone.run(() => {
        this.currentUser = user;
        if (user && user.email) {
          console.log('User logged in:', user.email);
          this.userEmail = user.email;
          this.loadAssignedTasksRealtime(user.email);
          this.loadAttendanceHistory();
          this.checkForAutoTimeout();
          this.fetchAttendanceSummary(); // <--- CALL THIS HERE
        } else {
          console.log('No logged-in user or email found');
          this.userEmail = null;
          this.assignedTasks = [];
          this.attendanceHistory = [];
          this.currentOngoingRecord = null;
          // Clear summary data if no user
          this.totalCompletedMinutes = 0;
          this.totalCompletedHoursDisplay = 0;
          this.remainingHours = this.targetTotalHours; // Reset to full target
          // Clean up subscriptions
          if (this.tasksSubscription) {
            this.tasksSubscription();
            this.tasksSubscription = undefined;
          }
          if (this.attendanceSubscription) {
            this.attendanceSubscription();
            this.attendanceSubscription = undefined;
          }
        }
      });
    });

    this.updateClock();
    this.timer = setInterval(() => {
      this.updateClock();
    }, 1000);
  }

  updateClock() {
    const now = new Date();
    this.currentDateTime = now.toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  }

  ngOnDestroy() {
    clearInterval(this.timer);
    if (this.authSubscription) {
      this.authSubscription();
    }
    if (this.tasksSubscription) {
      this.tasksSubscription();
    }
    if (this.attendanceSubscription) {
      this.attendanceSubscription();
    }
  }

  goToProfile() {
    this.router.navigate(['/profile'], {
      state: { fromPage: '/home' }
    });
  }

  loadAssignedTasksRealtime(userEmail: string) {
    const tasksRef = collection(this.firestore, 'tasks');
    const q = query(
      tasksRef,
      where('assignedWorker', '==', userEmail),
      where('status', '==', 'pending')
    );

    this.tasksSubscription = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        const tasks: any[] = [];
        querySnapshot.forEach(doc => {
          tasks.push({ id: doc.id, ...doc.data() });
        });
        this.assignedTasks = tasks;
        console.log('Realtime loaded tasks:', this.assignedTasks);
      });
    }, error => {
      console.error('Error getting realtime tasks:', error);
      this.presentToast('Error loading your tasks.', 'danger');
    });
  }

  // --- ATTENDANCE MONITORING LOGIC ---

  async presentToast(message: string, color: string = 'primary', duration: number = 2000) {
    const toast = await this.toastController.create({
      message: message,
      duration: duration,
      color: color,
      position: 'bottom'
    });
    toast.present();
  }

  async timeIn() {
    if (!this.currentUser?.uid) {
      this.presentToast('Please log in to time in.', 'warning');
      return;
    }

    if (this.currentOngoingRecord && this.currentOngoingRecord.status === 'ongoing') {
      this.presentToast('You are already timed in.', 'warning');
      return;
    }

    const now = new Date();
    const todayDate = now.toISOString().slice(0, 10);

    const newRecord: AttendanceRecord = {
      timeIn: Timestamp.fromDate(now),
      timeOut: null,
      status: 'ongoing',
      totalTime: null,
      date: todayDate,
    };

    try {
      await addDoc(collection(this.firestore, `attendance/${this.currentUser.uid}/records`), newRecord);
      this.presentToast('Timed in successfully!', 'success');
    } catch (error) {
      console.error('Error timing in:', error);
      this.presentToast('Failed to time in. Please try again.', 'danger');
    }
  }

  async timeOut() {
    if (!this.currentUser?.uid) {
      this.presentToast('Please log in to time out.', 'warning');
      return;
    }

    if (!this.currentOngoingRecord || this.currentOngoingRecord.status !== 'ongoing') {
      this.presentToast('You are not currently timed in or already timed out.', 'warning');
      return;
    }

    const now = new Date();
    const timeInDate = this.currentOngoingRecord.timeIn.toDate();
    const totalTimeMinutes = (now.getTime() - timeInDate.getTime()) / (1000 * 60);

    try {
      await updateDoc(doc(this.firestore, `attendance/${this.currentUser.uid}/records`, this.currentOngoingRecord.id!), {
        timeOut: Timestamp.fromDate(now),
        status: 'completed',
        totalTime: totalTimeMinutes,
      });
      this.presentToast('Timed out successfully!', 'success');
    } catch (error) {
      console.error('Error timing out:', error);
      this.presentToast('Failed to time out. Please try again.', 'danger');
    }
  }

  private loadAttendanceHistory() {
    if (!this.currentUser?.uid) return;

    const recordsCollectionRef = collection(this.firestore, `attendance/${this.currentUser.uid}/records`);
    const q = query(recordsCollectionRef, orderBy('timeIn', 'desc'));

    this.attendanceSubscription = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        const records: AttendanceRecord[] = [];
        querySnapshot.forEach((docSnap) => {
          const data = docSnap.data() as AttendanceRecord;
          const id = docSnap.id;
          records.push({ id, ...data });
        });
        this.attendanceHistory = records;
        this.currentOngoingRecord = records.find(record => record.status === 'ongoing') || null;
        // Re-fetch summary whenever history changes to ensure data is fresh
        this.fetchAttendanceSummary();
      });
    }, (error) => {
      console.error('Error loading attendance history:', error);
      this.presentToast('Failed to load attendance history.', 'danger');
    });
  }

  private checkForAutoTimeout() {
    if (!this.currentUser?.uid) return;
    const userUid = this.currentUser.uid;

    const recordsCollectionRef = collection(this.firestore, `attendance/${userUid}/records`);
    const q = query(recordsCollectionRef, where('status', '==', 'ongoing'));

    getDocs(q)
      .then(async (querySnapshot) => {
        querySnapshot.forEach(async (docSnap) => {
          const record = docSnap.data() as AttendanceRecord;
          const recordId = docSnap.id;
          const timeInDate = record.timeIn.toDate();
          const now = new Date();

          // Define auto-timeout to be 4 PM for the day the time-in occurred
          const autoTimeoutTime = new Date(timeInDate.getFullYear(), timeInDate.getMonth(), timeInDate.getDate(), 16, 0, 0); // 4 PM

          if (now > autoTimeoutTime && record.status === 'ongoing') {
            const totalTimeMinutes = (autoTimeoutTime.getTime() - timeInDate.getTime()) / (1000 * 60);
            console.log(`Auto-timing out record ${recordId} for user ${userUid}`);
            try {
              await updateDoc(doc(this.firestore, `attendance/${userUid}/records`, recordId), {
                timeOut: Timestamp.fromDate(autoTimeoutTime),
                status: 'auto-timed-out',
                totalTime: totalTimeMinutes,
              });
              this.presentToast('Auto-timed out due to inactivity (4 PM rule).', 'warning', 3000);
            } catch (error) {
              console.error('Error during auto-timeout:', error);
              this.presentToast('Failed to auto-timeout. Please check manually.', 'danger');
            }
          }
        });
      })
      .catch(error => {
        console.error('Error checking for auto-timeout:', error);
        this.presentToast('Error checking for forgotten timeouts.', 'danger');
      });
  }

  // --- UPDATED METHOD FOR ATTENDANCE SUMMARY CALCULATION ---
  async fetchAttendanceSummary() {
    if (!this.currentUser?.uid) {
      console.log('No user UID available to fetch summary.');
      return;
    }

    const userUid = this.currentUser.uid;
    const recordsCollectionRef = collection(this.firestore, `attendance/${userUid}/records`);

    const q = query(recordsCollectionRef,
      where('status', 'in', ['completed', 'auto-timed-out'])
    );

    try {
      const querySnapshot = await getDocs(q);
      let totalMinutesAcrossAllRecords = 0;

      querySnapshot.forEach((docSnap) => {
        const record = docSnap.data() as AttendanceRecord;
        if (record.totalTime !== null && typeof record.totalTime === 'number') {
          totalMinutesAcrossAllRecords += record.totalTime;
        }
      });

      this.ngZone.run(() => {
        this.totalCompletedMinutes = totalMinutesAcrossAllRecords;
        this.totalCompletedHoursDisplay = parseFloat((totalMinutesAcrossAllRecords / 60).toFixed(2));

        // Calculate remaining hours based on the fixed target and completed hours
        this.remainingHours = parseFloat((this.targetTotalHours - this.totalCompletedHoursDisplay).toFixed(2));
        if (this.remainingHours < 0) {
            this.remainingHours = 0; // Ensure remaining hours doesn't go negative
        }

        console.log('Attendance Summary:', {
            targetTotalHours: this.targetTotalHours,
            totalCompletedHoursDisplay: this.totalCompletedHoursDisplay,
            totalCompletedMinutes: this.totalCompletedMinutes,
            remainingHours: this.remainingHours
        });
      });

    } catch (error) {
      console.error('Error fetching attendance summary:', error);
      this.presentToast('Failed to load attendance summary.', 'danger');
    }
  }

  // Helper functions for formatting time and date
  formatTime(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  }

  formatDate(timestamp: Timestamp | null): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate();
    return date.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' });
  }

  formatTotalTime(minutes: number | null): string {
    if (minutes === null) return 'N/A';
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.round(minutes % 60);
    return `${hours}h ${remainingMinutes}m`;
  }
}