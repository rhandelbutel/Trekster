import { Component, OnInit, NgZone  } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { deleteDoc, Firestore, collection, query, where, onSnapshot } from '@angular/fire/firestore';
import { Auth, onAuthStateChanged, User } from '@angular/fire/auth';
import { ToastController, LoadingController } from '@ionic/angular/standalone';
import { serverTimestamp, updateDoc, doc } from 'firebase/firestore';

@Component({
  selector: 'app-task',
  templateUrl: './task.page.html',
  styleUrls: ['./task.page.scss'],
  standalone: false,
})
export class TaskPage implements OnInit {
  assignedTasks: any[] = [];
  isTaskModalOpen = false;
  selectedTask: any = null;
  selectedTaskForDone: any = null; 
  userEmail: string | null = null;

  constructor(
    private toastController: ToastController,
    private auth: Auth,
    private firestore: Firestore,
    private menu: MenuController,
    private ngZone: NgZone 
  ) {}

  ngOnInit() {
    // Worker's auth
    onAuthStateChanged(this.auth, (user: User | null) => {
      this.ngZone.run(() => {
        if (user && user.email) {
          console.log('User logged in:', user.email);
          this.userEmail = user.email;
          this.loadAssignedTasksRealtime(user.email);
          this.loadFinishedTasksCount(user.email); 
        } else {
          console.log('No logged-in user or email found');
          this.assignedTasks = [];
          this.userEmail = null;
        }
      }); 
    });
  }
  // End of Worker's auth

  // Menu
  openMenu() {
    this.menu.open('second');
  }
  // End of Menu

  // Realtime printing of assigned task
  pendingTaskCount: number = 0;
  finishedTaskCount: number = 0;
  loadAssignedTasksRealtime(userEmail: string) {
    const tasksRef = collection(this.firestore, 'tasks');
    const q = query(tasksRef, where('assignedWorker', '==', userEmail), where('status', '==', 'pending'));

    onSnapshot(q, (querySnapshot) => {
      
      this.ngZone.run(() => {
        const tasks: any[] = [];
        querySnapshot.forEach(doc => {
          tasks.push({ id: doc.id, ...doc.data() });
        });
        this.assignedTasks = tasks;
        this.pendingTaskCount = tasks.length;
        console.log('Realtime loaded tasks:', this.assignedTasks);
      });
    }, error => {
      console.error('Error getting realtime tasks:', error);
    });
  }
  // Count finished task
 loadFinishedTasksCount(userEmail: string) {
  const tasksRef = collection(this.firestore, 'tasks');
  const q = query(tasksRef, where('assignedWorker', '==', userEmail), where('status', '==', 'finished'));

  onSnapshot(q, (querySnapshot) => {
    this.ngZone.run(() => {
      this.finishedTaskCount = querySnapshot.size;
      console.log('Finished tasks count:', this.finishedTaskCount);
    }); 
  }, error => {
    console.error('Error getting finished tasks count:', error);
  });
}

  // End of Realtime printing of assigned task
  openTaskModal(task: any) {
    this.selectedTask = task;
    this.isTaskModalOpen = true;
  }

  closeTaskModal() {
    this.isTaskModalOpen = false;
    this.selectedTask = null;
  }

  // Finished and Unfinished task modal popup
openDonePopup(task: any) {
  this.selectedTaskForDone = task;
  const donePopup = document.getElementById('done');
  if (donePopup) {
    donePopup.classList.add('show'); 
  }
}

closeDonePopup() {
  const donePopup = document.getElementById('done');
  if (donePopup) {
    donePopup.classList.remove('show');
  }
}
confirmDone() {
  if (this.selectedTaskForDone) {
    this.markTaskAsFinished(this.selectedTaskForDone.id);
    this.closeDonePopup();
  }
}
// End of Finished and Unfinished task modal popup

   // action finished
  async markTaskAsFinished(taskId: string) {
  try {
    const taskDocRef = doc(this.firestore, 'tasks', taskId);

    // Update task instead of deleting it
    await updateDoc(taskDocRef, {
      status: 'finished',
      finishedDate: serverTimestamp()
    });

    // Remove from UI list (pending tasks only)
    this.assignedTasks = this.assignedTasks.filter(task => task.id !== taskId);

    this.presentToast('top', 'Task marked as finished!');
  } catch (error) {
    console.error('Error updating task status:', error);
    this.presentToast('top', 'Failed to mark task as finished.');
  }
}


async presentToast(
    position: 'top' | 'middle' | 'bottom' = 'top',
    message: string = ''
  ) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: position,
    });
  
    await toast.present();
  }
}
