import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';
import { Firestore, collection, query, where, onSnapshot, Unsubscribe, doc, deleteDoc, writeBatch, getDocs } from '@angular/fire/firestore'; // Added doc, deleteDoc, writeBatch, getDocs
import { ToastController, LoadingController } from '@ionic/angular/standalone'; // Assuming you have ToastController and LoadingController

// Search bar variables
  interface Worker {
  id: string;
  username: string;
  email: string;
}
@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.page.html',
  styleUrls: ['./admin-home.page.scss'],
  standalone: false
})
export class AdminHomePage implements OnInit, OnDestroy {

  totalWorkerCount: number = 0;
  totalPendingWorkerCount: number = 0;
  workerUsers: any[] = [];
  pendingTaskCount: number = 0;
  finishedTaskCount: number = 0;
  showAllWorkers: boolean = false;
  filteredWorkers: Worker[] = [];
  searchTerm: string = '';
  
  // State for delete user popup
  isDeleteUserPopupOpen: boolean = false;
  userToDelete: { id: string, email: string, username: string } | null = null;


  private unsubscribeWorkerListener: Unsubscribe | undefined;
  private unsubscribePendingWorkerListener: Unsubscribe | undefined;
  private unsubscribeWorkerUsersListener: Unsubscribe | undefined;
  private unsubscribePendingAssignedTasksListener: Unsubscribe | undefined;
  private unsubscribeFinishedAssignedTasksListener: Unsubscribe | undefined;

  constructor(
    private firestore: Firestore,
    private ngZone: NgZone,
    private toastController: ToastController, 
    private loadingController: LoadingController 
  ) { }

  ngOnInit() {
    this.fetchTotalWorkerCountRealtime();
    this.fetchTotalPendingWorkerCountRealtime();
    this.fetchWorkerUsersRealtime();
    this.loadAssignedPendingTasksRealtime();
    this.loadAssignedFinishedTasksRealtime();
  }

  ngOnDestroy() {
    if (this.unsubscribeWorkerListener) {
      this.unsubscribeWorkerListener();
    }
    if (this.unsubscribePendingWorkerListener) {
      this.unsubscribePendingWorkerListener();
    }
    if (this.unsubscribeWorkerUsersListener) {
      this.unsubscribeWorkerUsersListener();
    }
    if (this.unsubscribePendingAssignedTasksListener) {
      this.unsubscribePendingAssignedTasksListener();
    }
    if (this.unsubscribeFinishedAssignedTasksListener) {
      this.unsubscribeFinishedAssignedTasksListener();
    }
  }

  fetchTotalWorkerCountRealtime() {
    const usersRef = collection(this.firestore, 'users');
    const q = query(usersRef, 
      where('role', '==', 'worker'),
      where('approved', '==', true));

    this.unsubscribeWorkerListener = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        this.totalWorkerCount = querySnapshot.size;
        console.log('Real-time total worker count:', this.totalWorkerCount);
      });
    }, (error) => {
      console.error('Error fetching real-time total worker count:', error);
    });
  }

  fetchTotalPendingWorkerCountRealtime() {
    const usersRef = collection(this.firestore, 'users');
    const q = query(
      usersRef,
      where('role', '==', 'worker'),
      where('approved', '==', false)
    );

    this.unsubscribePendingWorkerListener = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        this.totalPendingWorkerCount = querySnapshot.size;
        console.log('Real-time pending worker count:', this.totalPendingWorkerCount);
      });
    }, (error) => {
      console.error('Error fetching real-time pending worker count:', error);
    });
  }

  fetchWorkerUsersRealtime() {
    const usersRef = collection(this.firestore, 'users');
    const q = query(usersRef, where('role', '==', 'worker'), where('approved', '==', true));

    this.unsubscribeWorkerUsersListener = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        const workers: Worker[] = []; 
        querySnapshot.forEach(doc => {
          const userData = doc.data();
         
          workers.push({
            id: doc.id,
            username: userData && typeof userData['username'] === 'string' ? userData['username'] : 'N/A', 
            email: userData && typeof userData['email'] === 'string' ? userData['email'] : 'N/A'
          });
        });

        this.workerUsers = workers; 
        console.log('Real-time worker users list:', this.workerUsers);

        
        this.filterWorkers();
      });
    }, (error) => {
      console.error('Error fetching real-time worker users:', error);
    });
  }

  toggleWorkerListVisibility() {
    this.showAllWorkers = !this.showAllWorkers;
  }

  // --- Delete User Methods ---

  openDeleteUserPopup(worker: any) {
    this.userToDelete = {
      id: worker.id,
      email: worker.email,
      username: worker.username 
    };
    this.isDeleteUserPopupOpen = true;
  }

  cancelDeleteUser() {
    this.isDeleteUserPopupOpen = false;
    this.userToDelete = null;
  }

  async confirmDeleteUser() {
    if (!this.userToDelete || !this.userToDelete.id || !this.userToDelete.email) {
      this.presentToast('top', 'Error: No user selected for deletion.');
      this.cancelDeleteUser();
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Deleting user and tasks...',
      spinner: 'crescent'
    });
    await loading.present();

    try {
      const batch = writeBatch(this.firestore);

      const userDocRef = doc(this.firestore, 'users', this.userToDelete.id);
      batch.delete(userDocRef);
      console.log(`User document deletion added to batch: ${this.userToDelete.id}`);


      const tasksRef = collection(this.firestore, 'tasks');
      const q = query(tasksRef, where('assignedWorker', '==', this.userToDelete!.email)); 
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        querySnapshot.forEach(taskDoc => {
          const taskDocRef = doc(this.firestore, 'tasks', taskDoc.id);
          batch.delete(taskDocRef);
          
          console.log(`Task deletion added to batch: ${taskDoc.id} (assigned to ${this.userToDelete!.email})`); 
        });
        console.log(`Found and marked ${querySnapshot.size} tasks for deletion.`);
      } else {
        console.log(`No tasks found for user: ${this.userToDelete!.email}`); 
      }

      await batch.commit();

      this.presentToast('top', 'User and all associated tasks deleted successfully!');
      this.cancelDeleteUser();

    } catch (error) {
      console.error('Error deleting user and tasks:', error);
      this.presentToast('top', 'Error deleting user and tasks. Please try again.');
    } finally {
      await loading.dismiss();
    }
  }


  loadAssignedPendingTasksRealtime() {
    const tasksRef = collection(this.firestore, 'tasks');
    const q = query(
      tasksRef,
      where('status', '==', 'pending')
    );

    this.unsubscribePendingAssignedTasksListener = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        this.pendingTaskCount = querySnapshot.size;
        console.log('Pending Task Count:', this.pendingTaskCount);
      });
    }, error => {
      console.error('Error getting realtime pending task count:', error);
    });
  }

  loadAssignedFinishedTasksRealtime() {
    const tasksRef = collection(this.firestore, 'tasks');
    const q = query(
      tasksRef,
      where('status', '==', 'finished')
    );

    this.unsubscribeFinishedAssignedTasksListener = onSnapshot(q, (querySnapshot) => {
      this.ngZone.run(() => {
        this.finishedTaskCount = querySnapshot.size;
        console.log('Finished Task Count:', this.finishedTaskCount);
      });
    }, error => {
      console.error('Error getting realtime finished task count:', error);
    });
  }
  
  // Search bar
  filterWorkers() {
    const lowerCaseSearchTerm = this.searchTerm.trim().toLowerCase();

    if (lowerCaseSearchTerm === '') {
      this.filteredWorkers = [...this.workerUsers];
    } else {
      this.filteredWorkers = this.workerUsers.filter(worker => {
        return worker.email.toLowerCase().includes(lowerCaseSearchTerm);
      });
    }
    
  }
  async presentToast(
    position: 'top' | 'middle' | 'bottom' = 'top',
    message: string = ''
  ) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: position,
    });
    await toast.present();
  }
}